export class HelloWorld {
    public doIt() {
        console.log('Hello from MyApp');
    }
}
