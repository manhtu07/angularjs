import { HelloWorld } from './HelloWorld';
import './styles/main.less';

new HelloWorld().doIt();
