class Greeting {
    getMessage() {
        return 'Hello from the ES2015 class';
    }
}

console.log(new Greeting().getMessage());
