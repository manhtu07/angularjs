# Not for general use

This NPM package is an internal implementation detail of the `Microsoft.AspNetCore.SpaServices` NuGet package.

You should not use this package directly in your own applications, because it is not supported, and there are no
guarantees about how its APIs will change in the future.
