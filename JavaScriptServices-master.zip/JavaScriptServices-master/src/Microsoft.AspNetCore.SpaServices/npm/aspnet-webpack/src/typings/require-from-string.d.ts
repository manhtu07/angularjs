export namespace requirefromstring {
    export function requireFromString<T>(fileContent: string, filename?: string): T;
}
