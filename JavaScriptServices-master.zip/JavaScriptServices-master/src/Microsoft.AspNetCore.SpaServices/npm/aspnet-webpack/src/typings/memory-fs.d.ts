export namespace memoryfs {
    export class MemoryFS {}
}
