declare module 'webpack-node-externals' {
}
